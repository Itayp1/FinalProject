package singletonDemo;

public class SingletonDemo2 {

	   public static void main(String[] args) {
	      Singleton tmp = Singleton.getInstance( );
	      tmp.demoMethod( );
	      System.out.println(tmp);
	      
	      //659e0bfd
	   }
	}